# E-Voting.github.io
This code creates an Electronic Voting Portal which displays the voting results real-time with a user-friendly interface, animation effects, and interactive elements.
